import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-gallery',
  templateUrl: './my-gallery.component.html',
  styleUrls: ['./my-gallery.component.css']
})
export class MyGalleryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }



  
}
